-- Copyright (C) 2019 by chrono

ngx.log(ngx.INFO, "hello openresty")
ngx.say('hello openresty')
